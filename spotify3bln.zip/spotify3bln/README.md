![Screenshot_2023-01-21-14-33-33-391_com termux](https://user-images.githubusercontent.com/94370774/213849149-bcd47844-3f80-4d3f-b24e-75049ae6fb84.jpg)
![Screenshot_2023-01-21-14-34-48-075_com android chrome](https://user-images.githubusercontent.com/94370774/213849147-b8282313-35a8-48a1-8975-53917cafb754.jpg)
https://user-images.githubusercontent.com/94370774/213849407-f80a08e3-063c-41eb-bd03-59d03a1f04fa.mp4
<details>
    <summary>How to Use<b></b></summary><br/>

1. pkg install update
2. pkg install php
3. pkg install git
4. git clone https://github.com/tahaluindo/spotifybot
5. cd spotifybot
6. php index.php

# Offer

1. Login using the account created by the tool
2. Pay manual use our vcc
3. link plan : https://www.spotify.com/id/redirect-in-app/android_premium_promotion/?offerSlug=samsung-global2022-pdp-3m-3m-trial-one-time-code
</details>
<details>
    <summary>Emmmm...<b></b></summary><br/>
<p align='center'><a href="https://api.daily.dev/get?r=Koleksibot"><img src="https://telegra.ph/file/3f8b2987e6b010c467dd6.png?r=82s" width="150" alt="LulzGhost-Team BOT's Dev Card"/></a></p>

![TahaluIndo's card name](https://cardivo.vercel.app/api?name=Tahalu%20Indonesia&description=Hi,%20i%27m%20a%20front%20end%20web%20developer%20and%20i%27m%2020%20y.o.%20Nice%20to%20meet%20you%20%F0%9F%91%8B&image=https://telegra.ph/file/3f8b2987e6b010c467dd6.png?v=4&backgroundColor=%23ecf0f1&instagram=cyber_mrlinkerrorsystemoffical&linkedin=I%20Blackhat%20Indo%20Nesia%20%20Indonesia&github=tahaluindo&twitter=koleksibot&pattern=leaf&colorPattern=%23eaeaea)

![Metrics](https://metrics.lecoq.io/tahaluindo?template=classic&repositories.forks=true&languages=1&languages.colors=github&languages.threshold=0%25&config.timezone=Asia%2FJakarta)

</details>
<details>
    <summary><b>CLICK HERE 😝</b></summary><br/>
<h1  align='center'> Welcome To Tahaluindo 👻 </h1>
<p align='center'><a href="https://api.daily.dev/get?r=Koleksibot"><img src="https://api.daily.dev/devcards/f863db015cc04215878268bea4ef43f5.png?r=82s" width="150" alt="LulzGhost-Team BOT's Dev Card"/></a></p>
<p align='center'><a href="https://www.dmca.com/Protection/Status.aspx?ID=090f6134-5e5e-46fd-a879-b366b9a65060&refurl=https://github.com/koleksibot" target="_blank" title="Check Protection Status" class="dmca-badge"> <img src ="https://dmca.blob.core.windows.net/logos/internal/PP-Asset-6c307ca5-01f5-4171-afcf-da6dbeaa2494.jpg?st=2019-03-02T00%3A22%3A29Z&se=2028-03-03T00%3A22%3A00Z&sp=rw&sv=2018-03-28&sr=c&sig=5uj40e0WkJN4jO9efLP3CKvstLnc2LG%2BqWfMC6U4Ou0%3D" alt="DMCA.com for Github" /></a></p>
<a href="https://api.daily.dev/get?r=Koleksibot"><img src="https://opencollective.com/vuejs/contributors.svg?width=900" /></a>
<p align='center'>
<a href="https://api.daily.dev/get?r=Koleksibot"><img height="200" src="https://raw.githubusercontent.com/tahaluindo/tahaluindo/main/root.svg"></a>
<p align='center'>  I'm TahaluIndo (21 y.o) ! :sunglasses: </p>
<img width="800px" src="https://raw.githubusercontent.com/tahaluindo/tahaluindo/main/Black%20Purple%20and%20Cyan%20Neon%20Noir%20%20Vaporwave%20Sports%20YouTube%20Outro.gif" />
<p align='center'> I'd like to do project that has relation to anime. :ghost: </p>
</p>

![Jokowi](https://github-profile-summary-cards.vercel.app/api/cards/profile-details?username=tahaluindo&theme=monokai)

</p>
</details>
<a href="https://www.rootsec.xyz/"><img height="137px" src="https://github-readme-stats.vercel.app/api?username=tahaluindo&hide_title=true&hide_border=true&show_icons=true&include_all_commits=true&count_private=true&line_height=21&text_color=000&icon_color=000&bg_color=0,ea6161,ffc64d,fffc4d,52fa5a&theme=graywhite" /><!-- wi*quL3fcV --><img height="137px" src="https://github-readme-stats.vercel.app/api/top-langs/?username=tahaluindo&hide=html&hide_title=true&hide_border=true&layout=compact&langs_count=6&exclude_repo=comp426,Redventures-Movie-Quotes&text_color=000&icon_color=fff&bg_color=0,52fa5a,4dfcff,c64dff&theme=graywhite" /></a>
<p align="center">
  <img src="https://komarev.com/ghpvc/?username=tahaluindo&label=VIEWS&style=flat-square&color=blue" />
</p>
<p align='center'>
   <a href="https://www.facebook.com/ciciyber.squadindo.7"><img height="100" src="https://raw.githubusercontent.com/tahaluindo/tahaluindo/64478fa6dc44f9aa505ca49d384375946107db89/speed.svg"></a></p>
<p align='center'>
<details>
    <summary>&#127942 <b>GitHub Awards</b></summary><br/>

![Github Trophy](https://github-profile-trophy.vercel.app/?username=tahaluindo)

</details> 
:page_with_curl: I'm currently learning:
- Python
- PHP
- Golang
- HTML
- JAVA
- C++
- Javascript
</p>
<details>
:star: Here are some projects that I'm working on:

## Start
<!--START_SECTION:waka-->
<p align="center" height='130px'> <img src="https://github-readme-stats.vercel.app/api?username=tahaluindo&show_icons=true&hide_title=true&include_all_commits=true&line_height=21&bg_color=0,64FFDA,64FFDA,A9EFDE,F2FFFC&count_public=true&theme=graywhite" alt="crazychickendev"/> <img src="https://github-readme-stats.vercel.app/api/top-langs/?username=tahaluindo&layout=compact&show_icons=true&bg_color=0,EFFDF9,CBFFF3,64FFDA&theme=graywhite&hide_title=true" alt="root"/> </p>
<p align="center">
    <img src="https://github-readme-streak-stats.herokuapp.com/?user=tahaluindo">
</p>
</details>
# NOTE

• star and fork this repo, and i'll update auto pay soon
